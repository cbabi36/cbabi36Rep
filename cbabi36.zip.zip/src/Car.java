import java.util.NoSuchElementException;
import java.util.Scanner;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.PrintWriter;
import java.util.Arrays;
/**
 * <Represents a car object with attributes like make, model, year, and price.>
 *
 * CSC 1351 Programming Project No <1>
 * Section <2>
 *
 * @author <Colin Babin>
 * @since <3/17/2024>
 *
 */
class Car implements Comparable<Car> {
    private String make;
    private int year;
    private int price;

    // Constructor
    public Car(String make, int year, int price) {
        this.make = make;
        this.year = year;
        this.price = price;
    }

    // Getter methods
    public String getMake() {
        return make;
    }

    public int getYear() {
        return year;
    }

    public int getPrice() {
        return price;
    }

    /**
     * <Compares 2 different Car objects based on make and year. If it's different it sorts
     * by make, it it's the same it sorts by year.>
     *
     * CSC 1351 Programming Project No <1>
     * Section <2>
     *
     * @author <Colin Babin>
     * @since <3/17/2024>
     *
     */
    @Override
    public int compareTo(Car other) {
        if (!make.equals(other.make))
            return make.compareTo(other.make);
        else
            return Integer.compare(year, other.year);
    }

    /**
     * <String representation of Car object>
     *
     * CSC 1351 Programming Project No <1>
     * Section <2>
     *
     * @author <Colin Babin>
     * @since <3/17/2024>
     *
     */
    @Override
    public String toString() {
        return "Make: " + make + ", Year: " + year + ", Price: " + price;
    }
}
