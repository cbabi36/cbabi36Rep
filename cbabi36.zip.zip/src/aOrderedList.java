import java.util.NoSuchElementException;
import java.util.Scanner;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.PrintWriter;
import java.util.Arrays;
/**
 * <Represents ordered list for storing car objects in order.>
 *
 * CSC 1351 Programming Project No <1>
 * Section <2>
 *
 * @author <Colin Babin>
 * @since <3/17/2024>
 *
 */
class aOrderedList {
    private static final int SIZE_INCREMENTS = 20;
    private Comparable[] oList;
    private int listSize;
    private int numObjects;

    public aOrderedList() {
        numObjects = 0;
        listSize = SIZE_INCREMENTS;
        oList = new Comparable[listSize];
    }

    /**
     * <Adds comparable object to list while maintaining sorted order.
     * Increases in size if the list is full.>
     *
     * CSC 1351 Programming Project No <1>
     * Section <2>
     *
     * @author <Colin Babin>
     * @since <3/17/2024>
     *
     */
    public void add(Comparable newObject) {
        if (numObjects == listSize) {
            listSize += SIZE_INCREMENTS;
            oList = Arrays.copyOf(oList, listSize);
        }
        int i;
        for (i = numObjects - 1; i >= 0; i--) {
            if (oList[i].compareTo(newObject) < 0)
                break;
            oList[i + 1] = oList[i];
        }
        oList[i + 1] = newObject;
        numObjects++;
    }

    public int size() {
        return numObjects;
    }

    public Comparable get(int index) {
        if (index < 0 || index >= numObjects)
            throw new IndexOutOfBoundsException("Index: " + index + ", Size: " + numObjects);
        return oList[index];
    }

    public boolean isEmpty() {
        return numObjects == 0;
    }

    /**
     * <Removes element of specified index from ordered list and elements are
     * shifted to fill in the gap left by removed elements.>
     *
     * CSC 1351 Programming Project No <1>
     * Section <2>
     *
     * @author <Colin Babin>
     * @since <3/17/2024>
     *
     */
    public void remove(int index) {
        if (index < 0 || index >= numObjects)
            throw new IndexOutOfBoundsException("Index: " + index + ", Size: " + numObjects);
        for (int i = index; i < numObjects - 1; i++) {
            oList[i] = oList[i + 1];
        }
        numObjects--;
    }

    /**
     * <reset(): Resets iterator to beginning of the list.
     * next(): Returns next element in the iteration and advances the iterator.
     * hasNext(): Returns true if there are more elements in the iteration.
     * remove(): Removes the last element returned by the next() method.>
     *
     * CSC 1351 Programming Project No <1>
     * Section <2>
     *
     * @author <Colin Babin>
     * @since <3/17/2024>
     *
     */
    public void reset() {
        curr = 0;
    }

    public Comparable next() {
        if (!hasNext())
            throw new NoSuchElementException();
        return oList[curr++];
    }

    public boolean hasNext() {
        return curr < numObjects;
    }

    public void remove() {
        if (curr == 0)
            throw new IllegalStateException();
        for (int i = curr - 1; i < numObjects - 1; i++) {
            oList[i] = oList[i + 1];
        }
        numObjects--;
        curr--;
    }

    private int curr; // index of current element accessed via iterator methods
}
