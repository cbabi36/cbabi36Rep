import java.util.NoSuchElementException;
import java.util.Scanner;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.PrintWriter;
import java.util.Arrays;
/**
 * <Implements main program for reading input, processing, and generating output.>
 *
 * CSC 1351 Programming Project No <1>
 * Section <2>
 *
 * @author <Colin Babin>
 * @since <3/17/2024>
 *
 */
class Prog01_aOrderedList {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        System.out.print("Enter input filename: ");
        String inputFilename = scanner.nextLine();
        try {
            Scanner fileScanner = getInputFile(inputFilename);
            aOrderedList orderedList = new aOrderedList();
            while (fileScanner.hasNextLine()) {
                String line = fileScanner.nextLine();
                String[] parts = line.split(",");
                if (parts[0].equals("A")) {
                    // Add operation
                    String make = parts[1];
                    int year = Integer.parseInt(parts[2]);
                    int price = Integer.parseInt(parts[3]);
                    orderedList.add(new Car(make, year, price));
                } else if (parts[0].equals("D")) {
                    // Delete operation
                    String make = parts[1];
                    int year = Integer.parseInt(parts[2]);
                    int index = findIndex(orderedList, make, year);
                    if (index != -1)
                        orderedList.remove(index);
                }
            }
            fileScanner.close();

            PrintWriter writer = getOutputFile("Enter output filename: ");
            writer.println("Number of cars: " + orderedList.size());
            for (int i = 0; i < orderedList.size(); i++) {
                Car car = (Car) orderedList.get(i);
                writer.println(car.toString());
            }
            writer.close();
            System.out.println("Operation completed successfully.");
        } catch (FileNotFoundException e) {
            System.out.println("File not found. Program execution cancelled.");
        }
        scanner.close();
    }

    /**
     * <Prompts user for the input file name and validates file existence; returns a
     * PrintWriter object for the input file.>
     *
     * CSC 1351 Programming Project No <1>
     * Section <2>
     *
     * @author <Colin Babin>
     * @since <3/17/2024>
     *
     */
    private static Scanner getInputFile(String userPrompt) throws FileNotFoundException {
        Scanner scanner = new Scanner(System.in);
        while (true) {
            System.out.print(userPrompt);
            String filename = scanner.nextLine();
            File file = new File(filename);
            if (file.exists()) {
                return new Scanner(file);
            } else {
                System.out.println("File specified <" + filename + "> does not exist.");
                System.out.print("Would you like to continue? <Y/N> ");
                String choice = scanner.nextLine();
                if (choice.equalsIgnoreCase("N"))
                    throw new FileNotFoundException();
            }
        }
    }

    /**
     * <Prompts for output file name and validates file existence; returns a PrintWriter
     * object for the output file.>
     *
     * CSC 1351 Programming Project No <1>
     * Section <2>
     *
     * @author <Colin Babin>
     * @since <3/17/2024>
     *
     */
    private static PrintWriter getOutputFile(String userPrompt) throws FileNotFoundException {
        Scanner scanner = new Scanner(System.in);
        while (true) {
            System.out.print(userPrompt);
            String filename = scanner.nextLine();
            File file = new File(filename);
            try {
                PrintWriter writer = new PrintWriter(file);
                return writer;
            } catch (FileNotFoundException e) {
                System.out.println("File specified <" + filename + "> is incorrect.");
                System.out.print("Would you like to continue? <Y/N> ");
                String choice = scanner.nextLine();
                if (choice.equalsIgnoreCase("N"))
                    throw new FileNotFoundException();
            }
        }
    }

    /**
     * <Finds index of a Car with given make and year, and returns index found.>
     *
     * CSC 1351 Programming Project No <1>
     * Section <2>
     *
     * @author <Colin Babin>
     * @since <3/17/2024>
     *
     */
    private static int findIndex(aOrderedList orderedList, String make, int year) {
        for (int i = 0; i < orderedList.size(); i++) {
            Car car = (Car) orderedList.get(i);
            if (car.getMake().equals(make) && car.getYear() == year)
                return i;
        }
        return -1;
    }
}
